#include "Account.h"

Account::Account(){
	this -> _id = -1;
	this -> _activity = nullptr;
	this -> _monthly_activity_frequency = nullptr;
}


Account::Account(int id, Transaction** const activity, int* monthly_activity_frequency){
	this -> _id = id;
	
	this -> _monthly_activity_frequency = new int[12];
	for(int i = 0; i < 12; i++){
		(this -> _monthly_activity_frequency)[i] = monthly_activity_frequency[i];
	}

	this -> _activity = new Transaction* [12];
	for(int i = 0; i < 12; i++){
		if(activity[i] == nullptr){
			this -> _activity[i] = nullptr;
			continue;
		}

		(this -> _activity)[i] = new Transaction[monthly_activity_frequency[i]];
		
		for(int j = 0; j < monthly_activity_frequency[i]; j++){
			(this -> _activity)[i][j] = activity[i][j];
		}

		int n = monthly_activity_frequency[i];
		bool swapped;

		for(int k = 0; k < n - 1; k++){
			swapped = false;
			for(int j = 0; j < n - 1 - k; j++){
				if(_activity[i][j] >_activity[i][j+1]){
					swapped = true;
					Transaction temp = _activity[i][j];
					_activity[i][j] = _activity[i][j+1];
					_activity[i][j + 1] = temp;
				}
			}

			if(swapped == false){
				break;
			}
		}
	}
}


Account::~Account(){
	if(this -> _monthly_activity_frequency != nullptr){
		delete [] (this -> _monthly_activity_frequency);
	}
	
	if(this -> _activity != nullptr){
		for (int i = 0; i < 12; i++){
			if(this -> _activity[i] != nullptr){
				delete [] (this -> _activity)[i];
			}
		}
		
		delete [] (this -> _activity);
	}
}

Account::Account(const Account& rhs){
	this -> _id = rhs._id;
	
	this -> _monthly_activity_frequency = new int[12];
	for(int i = 0; i < 12; i++){
		(this -> _monthly_activity_frequency)[i] = rhs._monthly_activity_frequency[i];
	}

	this -> _activity = new Transaction* [12];
	for(int i = 0; i < 12; i++){
		if(rhs._activity[i] == nullptr){
			this -> _activity[i] = nullptr;
			continue;
		}

		(this -> _activity)[i] = new Transaction[_monthly_activity_frequency[i]];
		for(int j = 0; j < _monthly_activity_frequency[i]; j++){
			(this -> _activity)[i][j] = rhs._activity[i][j];
		}
	}
}

Account::Account(const Account& rhs, time_t start_date, time_t end_date){
	this -> _id = rhs._id;
	
	this -> _monthly_activity_frequency = new int[12];

	this -> _activity = new Transaction* [12];
	for(int i = 0; i < 12; i++){
		this -> _monthly_activity_frequency[i] = 0;		
		if(rhs._activity[i] == nullptr){
			this -> _activity[i] = nullptr;
			continue;
		}

		int array_temp_index = 0;
		for(int j = 0; j < rhs._monthly_activity_frequency[i]; j++){
			if(rhs._activity[i][j] < end_date && rhs._activity[i][j] > start_date){
				array_temp_index += 1;
			}
		}

		(this -> _activity)[i] = new Transaction[array_temp_index];
		array_temp_index = 0;
		for(int j = 0; j < rhs._monthly_activity_frequency[i]; j++){
			if(rhs._activity[i][j] < end_date && rhs._activity[i][j] > start_date){
				this -> _monthly_activity_frequency[i] += 1;
				this -> _activity[i][array_temp_index] = rhs._activity[i][j];
				array_temp_index++;
			}
		}
	}
}

Account::Account(Account&& rhs){
	this -> _id = rhs._id;
	this -> _activity = rhs._activity;
	this -> _monthly_activity_frequency = rhs._monthly_activity_frequency;
	rhs._activity = nullptr;
	rhs._monthly_activity_frequency = nullptr;
}

Account& Account::operator=(Account&& rhs){
	
	if(*this == rhs){
		return *this;
	}

	if(_activity != nullptr){
		delete [] (this -> _monthly_activity_frequency);
		
		for (int i = 0; i < 12; i++){
			delete [] (this -> _activity)[i];
		}
		
		delete [] (this -> _activity);
	}

	this -> _id = rhs._id;
	this -> _activity = rhs._activity;
	this -> _monthly_activity_frequency = rhs._monthly_activity_frequency;
	rhs._activity = nullptr;
	rhs._monthly_activity_frequency = nullptr;

	return *this;
}

Account& Account::operator=(const Account& rhs){

	if(*this == rhs){
		return *this;
	}

	if(_activity != nullptr){
		delete [] (this -> _monthly_activity_frequency);
		
		for (int i = 0; i < 12; i++){
			delete [] (this -> _activity)[i];
		}
		
		delete [] (this -> _activity);
	}

	this -> _id = rhs._id;
	
	this -> _monthly_activity_frequency = new int[12];
	for(int i = 0; i < 12; i++){
		(this -> _monthly_activity_frequency)[i] = rhs._monthly_activity_frequency[i];
	}

	this -> _activity = new Transaction* [12];
	for(int i = 0; i < 12; i++){
		if(rhs._activity[i] == nullptr){
			this -> _activity[i] = nullptr;
			continue;
		}

		(this -> _activity)[i] = new Transaction[_monthly_activity_frequency[i]];
		for(int j = 0; j < _monthly_activity_frequency[i]; j++){
			(this -> _activity)[i][j] = rhs._activity[i][j];
		}
	}
	
	return *this;
}

bool Account::operator==(const Account& rhs) const{
	if(this -> _id == rhs._id){
		return true;
	}
	return false;
}

bool Account::operator==(int id) const{
	if(this -> _id == id){
		return true;
	}
	return false;
}

Account& Account::operator+=(const Account& rhs){
	for(int i = 0; i < 12; i++){
		if(_monthly_activity_frequency[i] + rhs._monthly_activity_frequency[i] == 0){
			continue;
		}
		
		int j;
		Transaction* temp = this -> _activity[i];
		this -> _activity[i] = nullptr;
		this -> _activity[i] = new Transaction [rhs._monthly_activity_frequency[i] + (this -> _monthly_activity_frequency)[i]];
		for(j = 0; j < this -> _monthly_activity_frequency[i]; j++){
			_activity[i][j] = temp[j];
		}
		delete [] temp;
		for(j = this -> _monthly_activity_frequency[i]; j < rhs._monthly_activity_frequency[i] + this -> _monthly_activity_frequency[i]; j++){
			_activity[i][j] = rhs._activity[i][j - (this -> _monthly_activity_frequency[i])];
		}
		this -> _monthly_activity_frequency[i] += rhs._monthly_activity_frequency[i];

		int n = this -> _monthly_activity_frequency[i];
		Transaction* arr = _activity[i];

		bool swapped;

		for(int k = 0; k < n - 1; k++){
			swapped = false;
			for(int j = 0; j < n - 1 - k; j++){
				if(arr[j] > arr[j + 1]){
					swapped = true;
					Transaction temp = arr[j];
					arr[j] = arr[j+1];
					arr[j + 1] = temp;
				}
			}
			if(swapped == false){
				break;
			}
		}
	}
	return *this;
}

double Account::balance(){
	double result = 0;
	for(int i = 0; i < 12; i++){
		for(int j = 0; j < this -> _monthly_activity_frequency[i]; j++){
			result = this -> _activity[i][j] + result;
		}
	}
	return result;
}

double Account::balance(time_t end_date){
	double result = 0;
	for(int i = 0; i < 12; i++){
		for(int j = 0; j < this -> _monthly_activity_frequency[i]; j++){
			if(this -> _activity[i][j] < end_date){
				result = this -> _activity[i][j] + result;
			}
			else{
				return result;
			}
			
		}
	}
	return result;	
}

double Account::balance(time_t start_date, time_t end_date){
	double result = 0;
	for(int i = 0; i < 12; i++){
		for(int j = 0; j < this -> _monthly_activity_frequency[i]; j++){
			if(this -> _activity[i][j] > start_date){
				if(this -> _activity[i][j] < end_date){
					result = this -> _activity[i][j] + result;
				}
				else{
					return result;
				}
			}
		}
	}
	return result;	
}
    
std::ostream& operator<<(std::ostream& os, const Account& account){
	if(account._monthly_activity_frequency == nullptr || account._activity == nullptr){
		os << -1 << std::endl;
		return os; 
	}

	os << account._id << std::endl;
	for(int i = 0; i < 12; i++){
		for(int j = 0; j < account._monthly_activity_frequency[i]; j++){
			os << account._activity[i][j];
		}
	}
	return os;
}