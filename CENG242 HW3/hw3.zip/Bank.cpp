#include "Bank.h"

Bank::Bank(){
    _bank_name = "not_defined";
    _user_count = 0;
    _users = nullptr;
}

Bank::Bank(std::string bank_name, Account* const users, int user_count){
	_bank_name = bank_name;
	_user_count = user_count;
	
	_users = new Account[user_count];
	for(int i = 0; i < user_count; i++){
		_users[i] = users[i];
	}
}

Bank::~Bank(){
	delete [] _users;
}

Bank::Bank(const Bank& rhs){
	_bank_name = rhs._bank_name;
	_user_count = rhs._user_count;
	
	_users = new Account[_user_count];
	for(int i = 0; i < _user_count; i++){
		_users[i] = rhs._users[i];
	}	
}

Bank& Bank::operator+=(const Bank& rhs){

    Account* temp = new Account[_user_count + rhs._user_count];
    
    int arr_index = 0;

    for(int i = 0; i < _user_count; i++){
    	for(int j = 0; j < rhs._user_count; j++){
    		if(_users[i] == rhs._users[j]){
    			_users[i] += rhs._users[j];
    		}
    	}
    	temp[arr_index] = _users[i];
    	arr_index++;
    }

    for(int i = 0; i < rhs._user_count; i++){
    	int found = 0;
    	for(int j = 0; j < _user_count; j++){
    		if(rhs._users[i] == _users[j]){
    			found = 1;
    			break;
    		}
    	}
    	if(found == 0){
    		temp[arr_index] = rhs._users[i];
    		arr_index++;
    	}
    }

    delete [] _users;
    _user_count = arr_index;
    _users = new Account[_user_count];

    for(int i = 0; i < _user_count; i++){
    	_users[i] = temp[i];
    }

    delete [] temp;
    return *this;
}

Bank& Bank::operator+=(const Account& new_acc){

    Account* temp = new Account[_user_count + 1];
    
    int arr_index = 0;
    int added = 0;

    for(int i = 0; i < _user_count; i++){
    	if(_users[i] == new_acc){
    		_users[i] += new_acc;
    		added = 1;
    	}
    	temp[arr_index] = _users[i];
    	arr_index++;
    }

    if(added == 0){
    	temp[arr_index] = new_acc;
    	arr_index++;
    }

    delete [] _users;
    _user_count = arr_index;
    _users = new Account[_user_count];

    for(int i = 0; i < _user_count; i++){
    	_users[i] = temp[i];
    }

    delete [] temp;
    return *this;
}

Account& Bank::operator[](int account_id){
	for(int i = 0; i < _user_count; i++){
		if(_users[i] == account_id){
			return _users[i];
		}
	}
	return _users[0];
}

std::ostream& operator<<(std::ostream& os, const Bank& bank){
	double result_bal = 0;
	int result_users = bank._user_count;
	for(int i = 0; i < bank._user_count; i++){

		struct tm jan_beg = {0};
		jan_beg.tm_year = 119; jan_beg.tm_mon = 0; jan_beg.tm_mday = 1;
		time_t jan_beg_time = mktime(&jan_beg);
		
		struct tm feb_beg = {0};
		feb_beg.tm_year = 119; feb_beg.tm_mon = 1; feb_beg.tm_mday = 1;
		time_t feb_beg_time = mktime(&feb_beg);

		struct tm mar_beg = {0};
		mar_beg.tm_year = 119; mar_beg.tm_mon = 2; mar_beg.tm_mday = 1;
		time_t mar_beg_time = mktime(&mar_beg);

		struct tm apr_beg = {0};
		apr_beg.tm_year = 119; apr_beg.tm_mon = 3; apr_beg.tm_mday = 1;
		time_t apr_beg_time = mktime(&apr_beg);

		struct tm may_beg = {0};
		may_beg.tm_year = 119; may_beg.tm_mon = 4; may_beg.tm_mday = 1;
		time_t may_beg_time = mktime(&may_beg);

		struct tm jun_beg = {0};
		jun_beg.tm_year = 119; jun_beg.tm_mon = 5; jun_beg.tm_mday = 1;
		time_t jun_beg_time = mktime(&jun_beg);

		struct tm jul_beg = {0};
		jul_beg.tm_year = 119; jul_beg.tm_mon = 6; jul_beg.tm_mday = 1;
		time_t jul_beg_time = mktime(&jul_beg);

		struct tm aug_beg = {0};
		aug_beg.tm_year = 119; aug_beg.tm_mon = 7; aug_beg.tm_mday = 1;
		time_t aug_beg_time = mktime(&aug_beg);

		struct tm sep_beg = {0};
		sep_beg.tm_year = 119; sep_beg.tm_mon = 8; sep_beg.tm_mday = 1;
		time_t sep_beg_time = mktime(&sep_beg);

		struct tm oct_beg = {0};
		oct_beg.tm_year = 119; oct_beg.tm_mon = 9; oct_beg.tm_mday = 1;
		time_t oct_beg_time = mktime(&oct_beg);

		struct tm nov_beg = {0};
		nov_beg.tm_year = 119; nov_beg.tm_mon = 10; nov_beg.tm_mday = 1;
		time_t nov_beg_time = mktime(&nov_beg);

		struct tm dec_beg = {0};
		dec_beg.tm_year = 119; dec_beg.tm_mon = 11; dec_beg.tm_mday = 1;
		time_t dec_beg_time = mktime(&dec_beg);

		struct tm jan_beg_2020 = {0};
		jan_beg_2020.tm_year = 120; jan_beg_2020.tm_mon = 0; jan_beg_2020.tm_mday = 1;
		time_t jan_beg_2020_time = mktime(&jan_beg_2020);

		double total_balance = bank._users[i].balance();
		
		int avalibility_checker = 0;

		result_bal += total_balance;

		
		if(bank._users[i].balance(jan_beg_time, feb_beg_time) < 0){
			avalibility_checker = 1;
		}
		if(bank._users[i].balance(feb_beg_time, mar_beg_time) < 0){
			if(avalibility_checker == 1){
				result_users -= 1;
				continue;
			}
			avalibility_checker = 1;
		}
		if(bank._users[i].balance(mar_beg_time, apr_beg_time) < 0){
			if(avalibility_checker == 1){
				result_users -= 1;
				continue;
			}
			avalibility_checker = 1;
		}
		if(bank._users[i].balance(apr_beg_time, may_beg_time) < 0){
			if(avalibility_checker == 1){
				result_users -= 1;
				continue;
			}
			avalibility_checker = 1;
		}
		if(bank._users[i].balance(may_beg_time,jun_beg_time) < 0){
			if(avalibility_checker == 1){
				result_users -= 1;
				continue;
			}
			avalibility_checker = 1;
		}
		if(bank._users[i].balance(jun_beg_time, jul_beg_time) < 0){
			if(avalibility_checker == 1){
				result_users -= 1;
				continue;
			}
			avalibility_checker = 1;
		}
		if(bank._users[i].balance(jul_beg_time, aug_beg_time) < 0){
			if(avalibility_checker == 1){
				result_users -= 1;
				continue;
			}
			avalibility_checker = 1;
		}
		if(bank._users[i].balance(aug_beg_time, sep_beg_time) < 0){
			if(avalibility_checker == 1){
				result_users -= 1;
				continue;
			}
			avalibility_checker = 1;
		}
		if(bank._users[i].balance(sep_beg_time, nov_beg_time) < 0){
			if(avalibility_checker == 1){
				result_users -= 1;
				continue;
			}
			avalibility_checker = 1;
		}
		if(bank._users[i].balance(nov_beg_time, dec_beg_time) < 0){
			if(avalibility_checker == 1){
				result_users -= 1;
				continue;
			}
			avalibility_checker = 1;
		}
		if(bank._users[i].balance(dec_beg_time, jan_beg_2020_time) < 0){
			if(avalibility_checker == 1){
				result_users -= 1;
				continue;
			}
			avalibility_checker = 1;
		}
	}

	os << bank._bank_name << "\t" << result_users << "\t" << result_bal << std::endl;
	return os;
}